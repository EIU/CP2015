import java.io.*;
import java.util.*;

public class cargame2 {

	public static void main(String[] args) {
		int N = reader.nextInt();
		int M = reader.nextInt();

		String[] words = new String[N];

		long s = System.currentTimeMillis();
		@SuppressWarnings("unchecked")
		List<Byte>[][] charMaps = new ArrayList[N][26];
		for (int i = 0; i < N; i++) {
			String word = words[i] = reader.next();
			List<Byte>[] charMap = charMaps[i];
			for (byte j = 0; j < word.length(); j++) {
				byte index = (byte) (word.charAt(j) - 'a');
				if (charMap[index] == null) {
					charMap[index] = new ArrayList<Byte>();
				}
				charMap[index].add(j);
			}
		}
		System.out.println(System.currentTimeMillis() - s + "ms");
		byte[][] plates = new byte[M][3];
		for (int k = 0; k < M; k++) {
			String plate = reader.next();
			plates[k][0] = (byte) (plate.charAt(0) - 'A');
			plates[k][1] = (byte) (plate.charAt(1) - 'A');
			plates[k][2] = (byte) (plate.charAt(2) - 'A');
		}

		String[] results = new String[M];
		for (int i = 0; i < N; i++) {
			List<Byte>[] charMap = charMaps[i];
			for (int j = 0; j < M; j++) {
				if (results[j] != null) {
					continue;
				}
				byte[] plate = plates[j];
				List<Byte> list = charMap[plate[0]];
				if (list == null) {
					continue;
				}
				byte f0 = list.get(0);
				list = charMap[plate[2]];
				if (list == null) {
					continue;
				}
				byte f2 = list.get(list.size() - 1);
				if (f0 > f2) {
					continue;
				}
				list = charMap[plate[1]];
				if (list == null) {
					continue;
				}
				int index = Collections.binarySearch(list, (byte) (f0 + 1));
				if (index < 0) {
					index = ~index;
				}
				byte f1 = index < list.size() ? list.get(index) : (byte) 0xFF;
				if (f0 < f1 && f1 < f2) {
					results[j] = words[i];
				}
			}
		}

		System.out.println(System.currentTimeMillis() - s + "ms");
		for (int j = 0; j < M; j++) {
			if (results[j] == null) {
				results[j] = "No valid word";
			}
		}

		System.out.println(System.currentTimeMillis() - s + "ms");
		// System.out.println(String.join("\r\n", results));
	}

	static FastInputReader reader = new FastInputReader(System.in);

	static class FastInputReader {
		byte[] inbuf = new byte[1 << 25];
		int lenbuf = 0, ptrbuf = 0;
		InputStream is;

		public FastInputReader(InputStream stream) {
			is = stream;
		}

		int readByte() {
			if (lenbuf == -1)
				throw new InputMismatchException();
			if (ptrbuf >= lenbuf) {
				ptrbuf = 0;
				try {
					lenbuf = is.read(inbuf);
				} catch (IOException e) {
					throw new InputMismatchException();
				}
				if (lenbuf <= 0)
					return -1;
			}
			return inbuf[ptrbuf++];
		}

		public boolean hasNext() {
			return ptrbuf + 3 < lenbuf;
		}

		boolean isSpaceChar(int c) {
			return !(c >= 33 && c <= 126);
		}

		int skip() {
			int b;
			while ((b = readByte()) != -1 && isSpaceChar(b))
				;
			return b;
		}

		public String next() {
			int b = skip();
			StringBuilder sb = new StringBuilder();
			while (!(isSpaceChar(b))) {
				sb.appendCodePoint(b);
				b = readByte();
			}
			return sb.toString();
		}

		public char[] next(int n) {
			char[] buf = new char[n];
			int b = skip(), p = 0;
			while (p < n && !(isSpaceChar(b))) {
				buf[p++] = (char) b;
				b = readByte();
			}
			return n == p ? buf : Arrays.copyOf(buf, p);
		}

		double nextDouble() {
			return Double.parseDouble(next());
		}

		char nextChar() {
			return (char) skip();
		}

		public int nextInt() {
			int num = 0, b;
			boolean minus = false;
			while ((b = readByte()) != -1 && !((b >= '0' && b <= '9') || b == '-'))
				;
			if (b == '-') {
				minus = true;
				b = readByte();
			}

			while (true) {
				if (b >= '0' && b <= '9') {
					num = num * 10 + (b - '0');
				} else {
					return minus ? -num : num;
				}
				b = readByte();
			}
		}

		long nextLong() {
			long num = 0;
			int b;
			boolean minus = false;
			while ((b = readByte()) != -1 && !((b >= '0' && b <= '9') || b == '-'))
				;
			if (b == '-') {
				minus = true;
				b = readByte();
			}

			while (true) {
				if (b >= '0' && b <= '9') {
					num = num * 10 + (b - '0');
				} else {
					return minus ? -num : num;
				}
				b = readByte();
			}
		}
	}
}
